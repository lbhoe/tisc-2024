# Workplan
Setup monitoring and logs analysis process for PALINDROME. 
Compare products (we have 1 beta testing rights, need to source for others)

## Product 1: Meownitoring (Beta Test)
`https://d231g4hz442ywp.cloudfront.net`

1. Any sensitive info in logs / monitoring? 
2. How secure is the setup?
3. Usefulness of dashboard? Buggy? 

